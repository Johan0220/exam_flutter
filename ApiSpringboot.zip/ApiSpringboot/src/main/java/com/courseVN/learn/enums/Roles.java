package com.courseVN.learn.enums;

public enum Roles {
    ADMIN,
    USER,
    STAFF
}
