package com.courseVN.learn.controller;


import com.courseVN.learn.dto.response.ApiResponse;
import com.courseVN.learn.entity.Destination;
import com.courseVN.learn.repository.DestinationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/public")
public class publicController {


@Autowired
    private DestinationRepository _destinationRepository;

@GetMapping
    public ResponseEntity< List<Destination>> getall(){
     return ResponseEntity.ok( _destinationRepository.findAll() );
}


    @PostMapping
    public ResponseEntity<Destination> post(@RequestBody Destination destination){

        Destination destination1 = Destination.builder()
                .image(destination.getImage())
                .rate(destination.getRate())
                .title(destination.getTitle())
                .name(destination.getName())
                .build();

        _destinationRepository.save( destination1 );

        return ResponseEntity.ok(destination1);

    }

}
